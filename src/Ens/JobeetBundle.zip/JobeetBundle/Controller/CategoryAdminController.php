<?php

namespace Ens\JobeetBundle\Controller;
 
use Sonata\AdminBundle\Controller\CRUDController as Controller;
 
class CategoryAdminController extends Controller
{
 
}
?>
